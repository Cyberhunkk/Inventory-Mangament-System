create database IMS;
use IMS;

-- Create Products table
CREATE TABLE IF NOT EXISTS Products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(255),
    Description TEXT,
    Price DECIMAL(10, 2),
    QuantityOnHand INT
);

-- Create Suppliers table
CREATE TABLE IF NOT EXISTS Suppliers (
    SupplierID INT AUTO_INCREMENT PRIMARY KEY,
    SupplierName VARCHAR(255),
    ContactInfo VARCHAR(255)
);

-- Create Customers table
CREATE TABLE IF NOT EXISTS Customers (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerName VARCHAR(255),
    ContactInfo VARCHAR(255),
    Address TEXT
);

-- Create Orders table
CREATE TABLE IF NOT EXISTS Orders (
    OrderID INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID INT,
    OrderDate DATE,
    TotalAmount DECIMAL(10, 2),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Create OrderDetails table
CREATE TABLE IF NOT EXISTS OrderDetails (
    OrderDetailID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT,
    Subtotal DECIMAL(10, 2),
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Insert sample data into Products table
INSERT INTO Products (ProductName, Description, Price, QuantityOnHand) VALUES
    ('lays', 'french cheese', 30, 100),
    ('busicuits', 'prince', 40, 50),
    ('chocolates', 'dairy milk', 50, 75);

-- Insert sample data into Suppliers table
INSERT INTO Suppliers (SupplierName, ContactInfo) VALUES
    ('David', 'India'),
    ('Smith', 'England');

-- Insert sample data into Customers table
INSERT INTO Customers (CustomerName, ContactInfo, Address) VALUES
    ('Aly', '457248645', 'UK '),
    ('Lea', '325746245', 'London');

-- Insert sample data into Orders table
INSERT INTO Orders (CustomerID, OrderDate, TotalAmount) VALUES
    (1, '2023-01-01', 100.00),
    (2, '2023-02-15', 75.50);

-- Insert sample data into OrderDetails table
INSERT INTO OrderDetails (OrderID, ProductID, Quantity, Subtotal) VALUES
    (1, 1, 2, 51.98),
    (2, 3, 1, 35.50);


-- Add TotalAmount to OrderDetails table
ALTER TABLE OrderDetails
ADD COLUMN Totalamount DECIMAL(10, 2);

-- Update sample data in OrderDetails table
UPDATE OrderDetails
SET TotalAmount = Subtotal;

ALTER TABLE Orders
DROP COLUMN TotalAmount;

select * from Orders;
