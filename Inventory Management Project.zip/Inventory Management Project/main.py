import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import mysql.connector
from mysql.connector import Error

# Create a connection to the database
try:
    connection = mysql.connector.connect(
        host="localhost",
        username="root",
        password="pass123",
        database="IMS"
    )
except Error as e:
    print(f"Error: {e}")
    exit()

# Create a cursor to execute SQL queries
cursor = connection.cursor()

# Function to execute a SELECT query
def execute_select_query(query):
    try:
        cursor.execute(query)
        result = cursor.fetchall()
        display_query_result(result)
    except Error as e:
        messagebox.showerror("Error", f"Error executing: {e}")

# Function to execute a non-SELECT query (INSERT, UPDATE, DELETE, etc.)
def execute_query(query):
    try:
        cursor.execute(query)
        connection.commit()
        messagebox.showinfo("Success", "Executed successfully.")
    except Error as e:
        messagebox.showerror("Error", f"Error executing: {e}")

# Function to display the result of a SELECT query in a Text widget
def display_query_result(result):
    result_text.config(state=tk.NORMAL)
    result_text.delete(1.0, tk.END)

    if not result:
        result_text.insert(tk.END, "No results found.")
    else:
        header = [col[0] for col in cursor.description]
        result_text.insert(tk.END, "\t".join(header) + "\n")
        for row in result:
            result_text.insert(tk.END, "\t".join(map(str, row)) + "\n")

    result_text.config(state=tk.DISABLED)

# Function to handle button click for SELECT query
def on_select_query():
    query = select_query_entry.get()
    execute_select_query(query)

# Function to handle button click for non-SELECT query
def on_non_select_query():
    query = non_select_query_entry.get()
    execute_query(query)

# Function to handle button click for adding a product
def add_product():
    product_name = product_name_entry.get()
    description = description_entry.get()
    price = price_entry.get()
    quantity = quantity_entry.get()

    query = f"INSERT INTO Products (ProductName, Description, Price, QuantityOnHand) VALUES ('{product_name}', '{description}', {price}, {quantity})"
    execute_query(query)

# Function to handle button click for updating a product
def update_product():
    product_id = update_product_id_entry.get()
    new_price = new_price_entry.get()

    query = f"UPDATE Products SET Price = {new_price} WHERE ProductID = {product_id}"
    execute_query(query)

# Function to handle button click for removing a product
def remove_product():
    product_id = remove_product_id_entry.get()
    query = f"DELETE FROM Products WHERE ProductID = {product_id}"
    execute_query(query)

# Function to handle button click for viewing products
def view_products():
    query = "SELECT * FROM Products"
    execute_select_query(query)

# Function to handle button click for viewing suppliers
def view_suppliers():
    query = "SELECT * FROM Suppliers"
    execute_select_query(query)

# Function to handle button click for viewing customers
def view_customers():
    query = "SELECT * FROM Customers"
    execute_select_query(query)

# Function to handle button click for viewing orders
def view_orders():
    query = "SELECT * FROM Orders"
    execute_select_query(query)

# Function to handle button click for viewing order details
def view_order_details():
    query = "SELECT * FROM OrderDetails"
    execute_select_query(query)

# Create the main application window
app = tk.Tk()
app.title("Inventory Management System")
app.geometry("{0}x{1}+0+0".format(app.winfo_screenwidth(), app.winfo_screenheight()))  # Set window size to full screen

# Create and place widgets
title_label = ttk.Label(app, text=" Inventory Management System ", font=("Helvetica", 24, "bold"))
title_label.grid(row=0, column=0, columnspan=2, pady=10)

# Frame for functionalities on the left
functionality_frame = ttk.Frame(app)
functionality_frame.grid(row=1, column=0, padx=10, pady=10)

# Frame for results on the right
result_frame = ttk.Frame(app)
result_frame.grid(row=1, column=1, padx=10, pady=10)

# Widgets for adding a product
product_name_label = ttk.Label(functionality_frame, text="Product Name:")
product_name_label.grid(row=1, column=0, pady=5)
product_name_entry = ttk.Entry(functionality_frame, width=30)
product_name_entry.grid(row=1, column=1, pady=5)

description_label = ttk.Label(functionality_frame, text="Description:")
description_label.grid(row=2, column=0, pady=5)
description_entry = ttk.Entry(functionality_frame, width=30)
description_entry.grid(row=2, column=1, pady=5)

price_label = ttk.Label(functionality_frame, text="Price:")
price_label.grid(row=3, column=0, pady=5)
price_entry = ttk.Entry(functionality_frame, width=30)
price_entry.grid(row=3, column=1, pady=5)

quantity_label = ttk.Label(functionality_frame, text="Quantity:")
quantity_label.grid(row=4, column=0, pady=5)
quantity_entry = ttk.Entry(functionality_frame, width=30)
quantity_entry.grid(row=4, column=1, pady=5)

add_product_button = ttk.Button(functionality_frame, text="Add Product", command=add_product)
add_product_button.grid(row=5, column=0, columnspan=2, pady=10)

# Widgets for updating a product
update_product_id_label = ttk.Label(functionality_frame, text="Product ID to Update:")
update_product_id_label.grid(row=6, column=0, pady=5)
update_product_id_entry = ttk.Entry(functionality_frame, width=30)
update_product_id_entry.grid(row=6, column=1, pady=5)

new_price_label = ttk.Label(functionality_frame, text="New Price:")
new_price_label.grid(row=7, column=0, pady=5)
new_price_entry = ttk.Entry(functionality_frame, width=30)
new_price_entry.grid(row=7, column=1, pady=5)

update_product_button = ttk.Button(functionality_frame, text="Update Product", command=update_product)
update_product_button.grid(row=8, column=0, columnspan=2, pady=10)

# Widgets for removing a product
remove_product_id_label = ttk.Label(functionality_frame, text="Product ID to Remove:")
remove_product_id_label.grid(row=9, column=0, pady=5)
remove_product_id_entry = ttk.Entry(functionality_frame, width=30)
remove_product_id_entry.grid(row=9, column=1, pady=5)

remove_product_button = ttk.Button(functionality_frame, text="Remove Product", command=remove_product)
remove_product_button.grid(row=10, column=0, columnspan=2, pady=10)

# Buttons for viewing data
view_products_button = ttk.Button(functionality_frame, text="View Products", command=view_products)
view_products_button.grid(row=11, column=0, pady=10)

view_suppliers_button = ttk.Button(functionality_frame, text="View Suppliers", command=view_suppliers)
view_suppliers_button.grid(row=11, column=1, pady=10)

view_customers_button = ttk.Button(functionality_frame, text="View Customers", command=view_customers)
view_customers_button.grid(row=12, column=0, pady=10)

view_orders_button = ttk.Button(functionality_frame, text="View Orders", command=view_orders)
view_orders_button.grid(row=12, column=1, pady=10)

view_order_details_button = ttk.Button(functionality_frame, text="View Orders Detail", command=view_order_details)
view_order_details_button.grid(row=13, column=0, columnspan=2, pady=10)

# Result Text widget on the right side
result_text = tk.Text(result_frame, wrap=tk.WORD, height=30, width=100)
result_text.config(state=tk.DISABLED)
result_text.grid(row=0, column=0, padx=10, pady=10)

# Start the Tkinter event loop
app.mainloop()

# Close the cursor and connection when the application is closed
cursor.close()
connection.close()

